# Django Login App

A minimal Django project with a working authentication system:
register, log in, log out, and a protected home page — plus a
clean dark-themed UI, ready to deploy for free.

## What's inside

```
djangologin/
├── manage.py
├── requirements.txt      # Django, gunicorn, whitenoise
├── Procfile               # tells hosts how to run the app
├── runtime.txt             # pins the Python version
├── config/                 # project settings
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── accounts/                # the auth app
│   ├── forms.py             # RegisterForm
│   ├── views.py              # login / logout / register / home
│   └── urls.py
└── templates/
    ├── base.html
    └── accounts/
        ├── login.html
        ├── register.html
        └── home.html          # protected page (@login_required)
```

## 1. Run it locally

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser   # optional, for /admin/
python manage.py runserver
```

Visit `http://127.0.0.1:8000/` — you'll be redirected to `/login/`.
Click **Sign up** to create an account; you're logged in automatically
right after registering.

## 2. How the auth works

- Uses Django's **built-in** `django.contrib.auth` — no extra auth
  library needed.
- `accounts/forms.py` → `RegisterForm` extends `UserCreationForm`.
- `accounts/views.py`:
  - `register` — creates the user, then logs them in.
  - `UserLoginView` / `UserLogoutView` — thin wrappers around Django's
    built-in `LoginView` / `LogoutView`.
  - `home` — protected by `@login_required`; anonymous visitors get
    bounced to `/login/?next=/`.
- Settings you can tweak in `config/settings.py`:
  `LOGIN_URL`, `LOGIN_REDIRECT_URL`, `LOGOUT_REDIRECT_URL`.

To add email/password reset, swap in `django-allauth` later — this
project intentionally keeps to Django's built-ins so it has zero
extra moving parts to start.

## 3. Package it as a zip

Already done for you — but if you change the code and want to re-zip:

```bash
cd ..
zip -r djangologin.zip djangologin \
    -x "djangologin/venv/*" \
    -x "*__pycache__*" \
    -x "djangologin/db.sqlite3" \
    -x "djangologin/staticfiles/*"
```

## 4. Publish it online for free

Any of these will host a small Django app for free. Render is the
easiest for beginners.

### Option A — Render.com (recommended, easiest)

1. Push this folder to a **GitHub** repo (public or private).
2. Go to [render.com](https://render.com) → sign up free → **New +** →
   **Web Service** → connect your GitHub repo.
3. Render auto-detects Python. Set:
   - **Build Command:** `pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate`
   - **Start Command:** `gunicorn config.wsgi`
4. Add environment variables (Render dashboard → *Environment*):
   - `SECRET_KEY` = (generate one — see step 6 below)
   - `DEBUG` = `False`
   - `ALLOWED_HOSTS` = `your-app-name.onrender.com`
5. Click **Create Web Service**. Render builds and gives you a live
   `https://your-app-name.onrender.com` URL — free tier sleeps after
   inactivity but wakes on the next request.

### Option B — PythonAnywhere (free, no sleep, but manual setup)

1. Sign up free at [pythonanywhere.com](https://www.pythonanywhere.com).
2. Upload your zip via the **Files** tab and unzip it in a Bash console
   (`unzip djangologin.zip`), or `git clone` your repo.
3. Create a virtualenv and `pip install -r requirements.txt` inside it.
4. Go to the **Web** tab → **Add a new web app** → **Manual config** →
   pick your Python version → point it at `config/wsgi.py`.
5. In the WSGI config file PythonAnywhere gives you, make sure it
   imports `config.wsgi` and that your project path is on `sys.path`.
6. Set `ALLOWED_HOSTS = ["yourusername.pythonanywhere.com"]` in
   settings (or via env var), reload the web app.

### Option C — Railway.app / Fly.io

Both offer small free/trial tiers and auto-detect the `Procfile`:

- **Railway:** New Project → Deploy from GitHub repo → it reads the
  `Procfile` automatically → add the same env vars as above.
- **Fly.io:** `fly launch` in the project folder (it detects Django),
  then `fly deploy`. Free allowance covers small hobby apps.

### 5. Before going live, always set these

```bash
SECRET_KEY=<a long random string>
DEBUG=False
ALLOWED_HOSTS=your-domain.com
```

### 6. Generate a fresh SECRET_KEY

```bash
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

Never leave `DEBUG=True` or the default `SECRET_KEY` in production.

## Notes

- SQLite (the default DB) works for small/demo apps but resets on
  most free hosts' redeploys. For anything persistent, add a free
  Postgres add-on (Render, Railway, and Neon.tech all offer one) and
  point `DATABASES` at it via `dj-database-url`.
- Static files are served in production via **whitenoise** — no extra
  CDN or S3 setup needed for a small app.
